package comp4521.gunGame;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class GunGame extends Activity {
	/** Called when the activity is first created. */
	MediaPlayer player;
	

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.menu);
		player = MediaPlayer.create(this, R.raw.riff);
		player.setLooping(true); // Set looping
		player.start();
		// find button 1
		Button single = (Button) findViewById(R.id.button1);

		// find button 2
		Button multiple = (Button) findViewById(R.id.button2);

		// implement the onClickListener for button 1
		single.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				player.stop();
				startActivity(new Intent(GunGame.this, Single_Player.class));
			}
		});
		multiple.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				player.stop();
				startActivity(new Intent(GunGame.this, Multiple_Player.class));
			}
		});
	}

}
