package comp4521.gunGame;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class Single_Player extends Activity {
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.single_player);
		
		ImageButton pistol = (ImageButton) findViewById(R.id.pistol);
		ImageButton sniper = (ImageButton) findViewById(R.id.sniper);
		ImageButton shotgun = (ImageButton) findViewById(R.id.shotgun);
		pistol.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				startActivity(new Intent(Single_Player.this, Pistol.class));
			}
		});
		sniper.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				startActivity(new Intent(Single_Player.this, Sniper.class));
			}
		});
		shotgun.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				startActivity(new Intent(Single_Player.this, Shotgun.class));
			}
		});
	}

}
