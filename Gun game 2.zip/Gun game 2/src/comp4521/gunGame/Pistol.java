package comp4521.gunGame;

import android.app.Activity;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

public class Pistol extends Activity implements SensorEventListener {
	/** Called when the activity is first created. */
	MediaPlayer player;
	private SensorManager mSensorManager;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.pistol);

		mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);

	}

	protected void onResume() {
		super.onResume();
		mSensorManager.registerListener(this,
				mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
				SensorManager.SENSOR_DELAY_GAME);
		mSensorManager.registerListener(this,
				mSensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD),
				SensorManager.SENSOR_DELAY_GAME);
	}

	@Override
	protected void onStop() {
		mSensorManager.unregisterListener(this);
		super.onStop();
	}

	float[] mags = new float[3];
	float[] accels = new float[3];
	float[] RotationMat = new float[9];
	float[] InclinationMat = new float[9];
	float[] attitude = new float[3];
	final static double RAD2DEG = 180 / Math.PI;
	final String TAG = "Pistol";

	public void onAccuracyChanged(Sensor arg0, int arg1) {
		// TODO Auto-generated method stub

	}

	double max2 = 10;
	double min2 = 10;
	double max = 10;
	double min = 10;
	double difference;
	double difference2;
	boolean flag = false;

	public void onSensorChanged(SensorEvent event) {

		int type = event.sensor.getType();

		// Use this with the sensorsimulator instead of the above
		// int type = event.type;

		switch (type) {
		case Sensor.TYPE_ACCELEROMETER:
			accels = event.values;
			break;
		case Sensor.TYPE_MAGNETIC_FIELD:
			mags = event.values;

			break;
		}

		SensorManager.getRotationMatrix(RotationMat, InclinationMat, accels,
				mags);
		SensorManager.getOrientation(RotationMat, attitude);

		double yaw = attitude[0] * RAD2DEG;
		double pitch = attitude[1] * RAD2DEG;
		double roll = attitude[2] * RAD2DEG;



		if (pitch > -5 && pitch < 5) {

			min = pitch;
			min2 = yaw;
			flag = true;


		}

		if (flag == true) {

			max = pitch;
			max2 = yaw;

		}

		difference = max - min;
		difference2 = max2 - min2;
		if ((difference < -30) && flag == true) {

			player = MediaPlayer.create(this, R.raw.pistol);
			player.setLooping(false); // Set looping
			player.start();
			if(player.isPlaying()==false)player.reset();
			difference = 0;
			max = 10;
			min = 0;
			max2 = 10;
			min2 = 0;
			flag = false;

		}

		
	}
}